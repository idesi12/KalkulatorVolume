package com.example.kalkulatordesi;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private EditText panjang, lebar, tinggi;
    private EditText sisi;
    private EditText tinggi1,jari;
    private TextView tvHasil;
    private Button btnbalok;
    private Button btnkubus;
    private Button btntabung;
    private double sHasil = 0.0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnbalok = findViewById(R.id.btn_balok);
        btnkubus = findViewById(R.id.btn_kubus);
        btntabung = findViewById(R.id.btn_tabung);
        panjang = findViewById(R.id.et_panjang);
        lebar = findViewById(R.id.et_lebar);
        tinggi = findViewById(R.id.et_tinggi);
        tinggi1= findViewById(R.id.et_tinggi1);
        tvHasil = findViewById(R.id.tv_hasil);
        jari = findViewById(R.id.et_jari);
        sisi = findViewById(R.id.et_sisi1);

        btnbalok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    Double Panjang = Double.parseDouble(panjang.getText().toString());
                    Double Lebar = Double.parseDouble(lebar.getText().toString());
                    Double Tinggi = Double.parseDouble(tinggi.getText().toString());


                    Double balok =  Panjang * Lebar * Tinggi;
                    tvHasil.setText(String.valueOf(balok));

                }catch (Exception e) {
                    Toast.makeText(getApplicationContext(), "Field tidak boleh kosong", Toast.LENGTH_SHORT).show();
                }

            }
        });

        btnkubus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    Double Sisi = Double.parseDouble(sisi.getText().toString());


                    Double kubus = Sisi * Sisi * Sisi;
                    tvHasil.setText(String.valueOf(kubus));

                }catch (Exception e) {
                    Toast.makeText(getApplicationContext(), "Field tidak boleh kosong", Toast.LENGTH_SHORT).show();
                }

            }
        });

        btntabung.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
    double PHI = 3.14;
                try {
                    Double Jari = Double.parseDouble(jari.getText().toString());
                    Double Tinggi1 = Double.parseDouble(tinggi1.getText().toString());

                    Double tabung = PHI * Jari * Tinggi1;
                    tvHasil.setText(String.valueOf(tabung));

                }catch (Exception e) {
                    Toast.makeText(getApplicationContext(), "Field tidak boleh kosong", Toast.LENGTH_SHORT).show();
                }

            }
        });


    }
}
